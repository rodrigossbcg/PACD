from django.shortcuts import render
import pandas as pd
import os
from sklearn import mixture
from sklearn import model_selection
import pickle


def input(request):

    ####################################################################################################################
    # READ DATA FOR LABELS

    workpath = os.path.dirname(os.path.abspath(__file__))  # Returns the Path your .py file is in
    centros = pd.read_excel(os.path.join(workpath, 'databases/centros_de_formaçao_c_codigo.xlsx'))
    centros = centros.sort_values("DCENTRO_AB")

    motivo = pd.read_excel(os.path.join(workpath, 'databases/AgrupamentoMotivoInscricao.xlsx'))
    motivo_cod = motivo["Motivo"]
    motivo_desc = motivo["DMOTIVO_INSCRICAO"]
    motivos = zip(motivo_cod, motivo_desc)

    areas = pd.read_excel(os.path.join(workpath, 'databases/Desc_formacao.xlsx'))
    areas = areas.sort_values("DescAreaFormacaoEscolar")

    ### Criar labels para centros de emprego
    centros_cod = centros["CENTROA"]
    centros_desc = centros["DCENTRO_AB"]
    centros = zip(centros_cod, centros_desc)

    ### Criar labels para a area de formação do utente
    areas_cod = areas["AreaFormacao"]
    areas_desc = areas["DescAreaFormacaoEscolar"]
    areas = zip(areas_cod, areas_desc)

    iefp_norm = pd.read_csv(os.path.join(workpath, 'databases/dados_normalizados_cluster.csv'))

    ####################################################################################################################
    ####################################################################################################################
    # Cluster - GaussianMixture

    filename = os.path.join(workpath, 'databases/cluster_model.sav')
    modelo_GMM = pickle.load(open(filename, 'rb'))

    ####################################################################################################################
    ####################################################################################################################

    if request.method == "POST":

        age = int(request.POST.get('age'))
        hab = int(request.POST.get('hab'))
        hours = int(request.POST.get('hours'))
        area = int(request.POST.get('area'))
        cntr = int(request.POST.get('cntr'))
        qual_form = int(request.POST.get('qual_form'))
        cat = int(request.POST.get('cat'))
        mot = request.POST.get('mot')

        # command line print for confirmation
        print('age: ' + str(age))
        print('hab: ' + str(hab))
        print('hours: ' + str(hours))
        print('area: ' + str(area))
        print('cntr: ' + str(cntr))
        print('qual_form: ' + str(qual_form))
        print('cat: ' + str(cat))
        print('mot: ' + mot)

        ################################################################################################################
        # READ DATA FOR ALGORITHM
        
        data = pd.read_csv(os.path.join(workpath, 'databases/interface_django_tree.csv'))
        succ_rate = pd.read_csv(os.path.join(workpath, 'databases/succ_rate.csv'))
        centros = pd.read_excel(os.path.join(workpath, "databases/AgrupamentoCentrosRegiao.xlsx"))

        # join data with centros
        data = data.merge(centros, on="CodCEFP", how="left")

        ################################################################################################################

        ################################################################################################################
        # ALGORITHM

        # age filter
        scale = data["IdadeEmAnos"].max() - data["IdadeEmAnos"].min()
        proportion = 0.15
        min_age = age - scale * proportion
        max_age = age + scale * proportion
        data = data[(data["IdadeEmAnos"] > min_age) & (data["IdadeEmAnos"] < max_age)]

        # hour filter preparation
        scale = data["HorasForm"].max() - data["HorasForm"].min()
        proportion = 0.10
        min_hours = hours - scale * proportion
        max_hours = hours + scale * proportion
        data = data[(data["HorasForm"] > min_hours) & (data["HorasForm"] < max_hours)]

        # receber Centro e devolver Zona do País
        zona = centros[centros["CodCEFP"] == cntr]["Zona"]
        zona_index = zona.index[0]
        zona = zona[zona_index]
        print("Zona:" + zona)

        # center filter
        data = data[data["Zona"] == zona]

        # area filter
        data = data[data["AreaFormacao"] == area]

        abs_freq = pd.DataFrame(data["F_DCURSO"].value_counts())

        ################################################################################################################

        ################################################################################################################
        # OUTPUT

        # guardar os cursos recomendados cursos para o output
        index = abs_freq.index
        indexes = []

        for i in index:
            indexes.append(i)

        # filtrar apenas as taxas de sucesso necessárias
        succ_rate = succ_rate.set_index('F_DCURSO')
        succ_rate = succ_rate.loc[indexes]

        # Criar o score final usando a frequência absoluta e a taxa de sucesso por curso
        output = pd.concat([abs_freq, succ_rate], axis=1)
        output["final_score"] = output["F_DCURSO"] * (output["succ_rate"] + 0.05)
        output = output.sort_values("final_score", ascending=False)

        # Guardar final Scores
        final_scores = output["final_score"][0:10]

        # Guardar final_indexes
        final_indexes = output.index[0:10]

        # juntar scores e indexes
        final_output = zip(final_indexes, round(final_scores*10, 2))

        # enviar output para a página de outputs
        context = {'final_output': final_output}

        return render(request, 'interface/output_system.html', context)

    context = {'centros': centros, 'areas': areas, 'motivos': motivos}

    return render(request, 'interface/input_system.html', context)


def output(request):

    return render(request, 'interface/output_system.html')