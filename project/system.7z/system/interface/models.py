from django.db import models


class Success(models.Model):

    UTE_ID = models.IntegerField()
    CodCEFP = models.IntegerField()
    IdadeEmAnos = models.IntegerField()
    CodHabilitacao = models.IntegerField()
    AreaFormacao = models.IntegerField()
    HorasForm = models.IntegerField()
    #F_DCURSO = models.CharField

