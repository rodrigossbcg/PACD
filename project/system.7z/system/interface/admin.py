from django.contrib import admin
from .models import Success
from import_export.admin import ImportExportActionModelAdmin


@admin.register(Success)
class ViewAdmin(ImportExportActionModelAdmin):
    pass

